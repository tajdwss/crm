import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Wrench, Shield, User, Search, Plus, Clock, Zap, Phone, Mail, MapPin } from "lucide-react";
import { Logo } from "@/components/Logo";

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const [trackingNumber, setTrackingNumber] = useState("");

  const handleTrackRepair = () => {
    if (trackingNumber.trim()) {
      setLocation(`/track/${trackingNumber}`);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
      </div>

      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <Card className="bg-white/95 backdrop-blur-sm shadow-2xl border border-white/20">
            <CardHeader className="text-center pb-6">
              {/* Logo */}
              <Logo size="lg" showText={false} className="mx-auto mb-4" />
              
              {/* Title */}
              <CardTitle className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">
                New Taj Electronics
              </CardTitle>
              <p className="text-gray-600 text-sm">
                Professional Electronics Repair Service
              </p>
              <div className="w-16 h-1 bg-gradient-to-r from-blue-500 to-purple-500 mx-auto mt-3 rounded-full"></div>
            </CardHeader>

            <CardContent className="space-y-4">
              {/* Staff Login */}
              <Button 
                onClick={() => setLocation("/login")}
                className="w-full h-12 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold rounded-lg shadow-lg hover:shadow-xl transform hover:scale-[1.02] transition-all duration-200"
              >
                <Shield className="w-5 h-5 mr-2" />
                Access System
              </Button>
              <p className="text-xs text-center text-gray-500 -mt-2">
                Secure access to admin, technician, and service panels
              </p>

              {/* Divider */}
              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-200"></div>
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-white px-2 text-gray-500">Customer Services</span>
                </div>
              </div>

              {/* Track Repair */}
              <div className="space-y-3">
                <div className="flex gap-2">
                  <Input
                    placeholder="Enter receipt number (e.g., TD001)"
                    value={trackingNumber}
                    onChange={(e) => setTrackingNumber(e.target.value)}
                    className="flex-1 h-11 border-gray-300 focus:border-purple-500 focus:ring-purple-500"
                  />
                  <Button 
                    onClick={handleTrackRepair}
                    className="h-11 px-4 bg-purple-600 hover:bg-purple-700 text-white"
                  >
                    <Search className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Service Request */}
              <Button 
                onClick={() => setLocation("/customer-service-request")}
                className="w-full h-11 bg-green-600 hover:bg-green-700 text-white font-medium rounded-lg"
              >
                <Plus className="w-4 h-4 mr-2" />
                Submit Service Request
              </Button>

              {/* Service Features */}
              <div className="grid grid-cols-2 gap-4 mt-6">
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <Clock className="w-6 h-6 text-blue-600 mx-auto mb-1" />
                  <p className="text-xs font-semibold text-blue-800">24/7</p>
                  <p className="text-xs text-blue-600">Support</p>
                </div>
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <Zap className="w-6 h-6 text-green-600 mx-auto mb-1" />
                  <p className="text-xs font-semibold text-green-800">Fast</p>
                  <p className="text-xs text-green-600">Service</p>
                </div>
              </div>

              {/* Contact Info */}
              <div className="mt-6 p-4 bg-gray-50 rounded-lg space-y-2">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Phone className="w-4 h-4" />
                  <span>+91 98930 73666</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Mail className="w-4 h-4" />
                  <span>info@tajdws.com</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <MapPin className="w-4 h-4" />
                  <span>Electronics Market, City</span>
                </div>
              </div>

              {/* Footer */}
              <div className="text-center pt-4 border-t border-gray-200">
                <p className="text-xs text-gray-500">
                  © 2025 New Taj Electronics. All rights reserved.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}



