import React, { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Search, FileText, Wrench, Phone, Calendar, MapPin } from "lucide-react";

export default function CustomerSearch() {
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSearch = async () => {
    if (!searchTerm.trim()) return;
    
    setIsLoading(true);
    try {
      const response = await fetch(`/api/customer-search?q=${encodeURIComponent(searchTerm)}`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log("Search results:", data); // Debug log
      setSearchResults(data);
    } catch (error) {
      console.error("Search failed:", error);
      setSearchResults({
        receipts: [],
        services: [],
        totalRecords: 0
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-gray-200">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                onClick={() => setLocation("/")}
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="w-4 h-4" />
                <span className="hidden sm:inline">Back to Home</span>
              </Button>
              <div className="h-6 w-px bg-gray-300 hidden sm:block" />
              <div>
                <h1 className="text-xl sm:text-2xl font-bold text-gray-900">Customer Search</h1>
                <p className="text-sm text-gray-600 hidden sm:block">Track repairs and service requests</p>
              </div>
            </div>
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
              <Search className="w-5 h-5 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Search Card */}
          <Card className="mb-8 shadow-lg border-0 bg-white/80 backdrop-blur-sm">
            <CardHeader className="text-center pb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <FileText className="w-8 h-8 text-white" />
              </div>
              <CardTitle className="text-2xl sm:text-3xl font-bold text-gray-900">
                Track Your Repair
              </CardTitle>
              <p className="text-gray-600 mt-2">
                Enter your receipt or service number to check repair status
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Receipt or Service Number *
                  </label>
                  <Input
                    placeholder="Enter tracking number (e.g., TD001, SC001)"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="h-12 text-lg"
                    onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                  />
                </div>
                <Button 
                  onClick={handleSearch}
                  disabled={isLoading || !searchTerm.trim()}
                  className="w-full h-12 text-lg font-semibold bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                >
                  <Search className="w-5 h-5 mr-2" />
                  {isLoading ? "Searching..." : "Track Repair Status"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Search Results */}
          {searchResults && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold text-gray-900">
                Search Results ({searchResults.totalRecords} found)
              </h2>

              {/* Receipts */}
              {searchResults.receipts?.length > 0 && (
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-800 flex items-center">
                    <FileText className="w-5 h-5 mr-2 text-blue-600" />
                    Repair Receipts
                  </h3>
                  <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                    {searchResults.receipts.map((receipt) => (
                      <Card key={receipt.id} className="hover:shadow-lg transition-shadow">
                        <CardContent className="p-6">
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <Badge variant="outline" className="font-mono">
                                {receipt.receiptNumber}
                              </Badge>
                              <Badge className={
                                receipt.status === 'completed' ? 'bg-green-100 text-green-800' :
                                receipt.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                                'bg-yellow-100 text-yellow-800'
                              }>
                                {receipt.status}
                              </Badge>
                            </div>
                            <div>
                              <h4 className="font-semibold text-gray-900">{receipt.customerName}</h4>
                              <p className="text-sm text-gray-600 flex items-center mt-1">
                                <Phone className="w-3 h-3 mr-1" />
                                {receipt.mobile}
                              </p>
                            </div>
                            <div className="text-sm text-gray-600">
                              <p className="font-medium">{receipt.product} - {receipt.model}</p>
                              <p className="text-xs mt-1 flex items-center">
                                <Calendar className="w-3 h-3 mr-1" />
                                {new Date(receipt.createdAt).toLocaleDateString('en-IN')}
                              </p>
                            </div>
                            <div className="pt-2 border-t">
                              <p className="text-sm font-medium text-gray-900">
                                Amount: ₹{receipt.estimatedAmount?.toLocaleString()}
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {/* Services */}
              {searchResults.services?.length > 0 && (
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-800 flex items-center">
                    <Wrench className="w-5 h-5 mr-2 text-purple-600" />
                    Service Requests
                  </h3>
                  <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                    {searchResults.services.map((service) => (
                      <Card key={service.id} className="hover:shadow-lg transition-shadow">
                        <CardContent className="p-6">
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <Badge variant="outline" className="font-mono">
                                {service.complaintNumber}
                              </Badge>
                              <Badge className={
                                service.status === 'completed' ? 'bg-green-100 text-green-800' :
                                service.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                                'bg-yellow-100 text-yellow-800'
                              }>
                                {service.status}
                              </Badge>
                            </div>
                            <div>
                              <h4 className="font-semibold text-gray-900">{service.customerName}</h4>
                              <p className="text-sm text-gray-600 flex items-center mt-1">
                                <Phone className="w-3 h-3 mr-1" />
                                {service.mobile}
                              </p>
                            </div>
                            <div className="text-sm text-gray-600">
                              <p className="font-medium">{service.productType}</p>
                              <p className="text-xs mt-1 flex items-center">
                                <Calendar className="w-3 h-3 mr-1" />
                                {new Date(service.createdAt).toLocaleDateString('en-IN')}
                              </p>
                              {service.address && (
                                <p className="text-xs mt-1 flex items-center">
                                  <MapPin className="w-3 h-3 mr-1" />
                                  {service.address.substring(0, 30)}...
                                </p>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {/* No Results */}
              {searchResults.totalRecords === 0 && (
                <Card className="text-center py-12">
                  <CardContent>
                    <Search className="w-16 h-16 mx-auto text-gray-400 mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">No Results Found</h3>
                    <p className="text-gray-600">
                      No records found for "{searchTerm}". Please check the number and try again.
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}





